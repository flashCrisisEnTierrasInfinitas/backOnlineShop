<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\categoryProduct;
use Illuminate\Http\Request;

class CategoryProdutController extends Controller
{
    public function index()
    {
       $category = categoryProduct::all();
       return response()->json($category);
    }
    public function store(Request $request)
    {
        $category = new categoryProduct();

        $category->name=$request->name;
        $category->state=$request->state;
        $category->color=$request->color;

        $category->save();

        return response()->json(['message' => 'success']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
